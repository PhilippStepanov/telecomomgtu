﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;
using System.Linq;
using System.Threading.Tasks;

namespace Telecom.Auth
{
    public class User : IdentityUser
    {
        public string Surname { get; set; }
        public string Lastname { get; set; }
        public string Otch { get; set; }
        public int Mobile { get; set; }
        public string Adress { get; set; }
        public int Balance { get; set; }
        public string Plans { get; set; }
        public string Video { get; set; }
        public string Contract { get; set; }
    }
}
