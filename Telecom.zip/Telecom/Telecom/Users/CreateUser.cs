﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace Telecom.Users
{
    public class CreateUser
    {
        [Required, MaxLength(20)]
        public string LogName { get; set; }
        [Required, DataType(DataType.Password)]
        public string Pass { get; set; }
        public string Surname { get; set; }
        public string Lastname { get; set; }
        public string Otch { get; set; }
        public int Mobile { get; set; }
        public string Adress { get; set; }
        public int Balance { get; set; }
        public string Plans { get; set; }
        public string Video { get; set; }
        public string Contract { get; set; }
        public string Email { get; set; }
    }
}
