﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Telecom.Entitys;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Telecom.Auth;

namespace Telecom.ContextFolder
{
    public class DataContext : IdentityDbContext<User>
    {

        public DataContext(DbContextOptions options) : base(options) { }
        
        public DbSet<UserClient> UserClients { get; set; }
    }
}
